// modules
import { Pipe, PipeTransform } from '@angular/core' ;

// énumérations
import { MenuStatus } from '../enum/menu-status' ;

// classes
import { Menu } from '../model/menu' ;

/**
 * Pipe permettant de convertir les données d'un menu (cf. API)
 * en objet de la classe Menu.
 * 
 * Date de dernière modification :
 * - Mercredi 12 février 2025 -
 * 
 * @author Victor Jockin
 * Groupe 2B, BUT2
 */
@Pipe({ name: 'toMenuObject' })
export class ToMenuObjectPipe implements PipeTransform
{
  transform(value: any): Menu
  {
    return new Menu(
      value.id,
      value.nom,
      value.description,
      value.date_creation,
      value.statut == "actif" ? MenuStatus.ACTIVE : MenuStatus.INACTIVE
    ) ;
  }
}