// modules
import { Pipe, PipeTransform } from '@angular/core' ;

// énumérations
import { MenuStatus } from '../../enum/menu-status' ;

/**
 * Pipe permettant de traduire du contenu en français.
 * 
 * Date de dernière modification :
 * - Dimanche 23 mars 2025 -
 * 
 * @author Victor Jockin
 * Groupe 2B, BUT2
 */
@Pipe({ name: 'intofrench' })
export class IntoFrenchPipe implements PipeTransform
{
  transform(value:any): string {
    switch (value) {
      case MenuStatus.ACTIVE   : return "Actif" ;
      case MenuStatus.INACTIVE : return "Inactif" ;
      default                  : return value ;
    }
  }
}