/**
 * Fonctions utilitaires de filtre.
 * 
 * Date de dernière modification :
 * - Samedi 5 avril 2025 -
 * 
 * @author Victor Jockin
 * Groupe 2B, BUT2
 */

// pipes
import { IntoFrenchPipe } from "../pipe/translation/into-french.pipe" ;

// fonctions utilitaires
import { normalizeText } from "./text-normalisation" ;

// filtre une liste par mots clés
export function filterByKeywords(
  list     : any[],
  fields   : string[],
  keywords : string,
): any[] {
  if (keywords && keywords.trim()) {
    const intoFrenchPipe = new IntoFrenchPipe() ;
    const normalizedKeywords = normalizeText(keywords.trim()).split(/\s+/) ;
    return list.filter(object => {
      const normalizedFields = fields.map(
        field => normalizeText(String(intoFrenchPipe.transform(object[field]) ?? ""))
      ).join(' ') ;
      return normalizedKeywords.every(word => normalizedFields.includes(word)) ;
    }) ;
  }
  return list ;
}